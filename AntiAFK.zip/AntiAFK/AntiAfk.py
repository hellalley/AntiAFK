import discord, time, os, colorama, random, asyncio
from time import sleep
from colorama import Fore, Style
from discord.ext import commands
from random import randint


def clear():
    os.system('cls')

clear()

client = discord.Client()
prefix = "$"
client = commands.Bot(
    command_prefix=prefix,
    self_bot=True
)

client = commands.Bot(command_prefix=commands.when_mentioned_or("$"))

token = input(f'{Fore.RED}Enter {Fore.RED}Token:{Fore.CYAN} ')

def start():
   print(f'''
{Fore.LIGHTMAGENTA_EX}▄▄▄       ███▄    █ ▄▄▄█████▓ ██▓    ▄▄▄        █████▒ ██ ▄█▀
{Fore.LIGHTMAGENTA_EX}▒████▄     ██ ▀█   █ ▓  ██▒ ▓▒▓██▒   ▒████▄    ▓██   ▒  ██▄█▒ 
{Fore.LIGHTMAGENTA_EX}▒██  ▀█▄  ▓██  ▀█ ██▒▒ ▓██░ ▒░▒██▒   ▒██  ▀█▄  ▒████ ░ ▓███▄░ 
{Fore.LIGHTMAGENTA_EX}░██▄▄▄▄██ ▓██▒  ▐▌██▒░ ▓██▓ ░ ░██░   ░██▄▄▄▄██ ░▓█▒  ░ ▓██ █▄ 
{Fore.LIGHTMAGENTA_EX} ▓█   ▓██▒▒██░   ▓██░  ▒██▒ ░ ░██░    ▓█   ▓██▒░▒█░    ▒██▒ █▄
{Fore.LIGHTMAGENTA_EX} ▒▒   ▓▒█░░ ▒░   ▒ ▒   ▒ ░░   ░▓      ▒▒   ▓▒█░ ▒ ░    ▒ ▒▒ ▓▒
{Fore.LIGHTMAGENTA_EX}  ▒   ▒▒ ░░ ░░   ░ ▒░    ░     ▒ ░     ▒   ▒▒ ░ ░      ░ ░▒ ▒░
{Fore.LIGHTMAGENTA_EX}  ░   ▒      ░   ░ ░   ░       ▒ ░     ░   ▒    ░ ░    ░ ░░ ░ 
{Fore.LIGHTMAGENTA_EX}      ░  ░         ░           ░           ░  ░        ░  ░   
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 
                    5 second Delay every ping
         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                                   

{Fore.CYAN}     This AntiAFK Was Made By: {Fore.WHITE}hellalley
{Fore.CYAN}     Logged in as:{Fore.RED}[{Fore.WHITE}{client.user.name}{Fore.WHITE}#{Fore.WHITE}{client.user.discriminator}{Fore.RED}]
''')




@client.event
async def on_ready():
    os.system(f'title [Anti AFK]')
    os.system(f'mode 60,20')
    clear()
    start()

@client.event
async def on_message(message):
    if client.user.mentioned_in(message):
      time.sleep(randint(1,5)) #msg delay
      await message.channel.send(random.choice(['focus', 'z','stay awake', '??', 'pressure', 'dont fall asleep', 'keep afk checking L', 'why do you even try', 'beg', "🤓", "lzz and im sleeping", "my son u suck", "u suck", "lame ass boy", "troll,", "shutup im sleeping", "ur dying", "ur horrible", "awwwww u already wanna quit", "u already wanna go", "ahahahahha ur tired", "my son soo tired", "XD", "LOL", "lz keep packing", "ok"])) #msg to send   
    if client.user.mentioned_in(message):
      time.sleep(randint(1,2)) #reaction delay
      await message.add_reaction(random.choice(["💤","👍", "🤓","🛏️", "🧋", "😴", "😐", "😭"])) #reaction emojis

while True:
    client.run(token, bot=False)
