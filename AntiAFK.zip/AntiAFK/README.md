dis code is used to respond to whenever u get pinged

 reactions and sends a message when you're pinged

 if u need help dm me tickets to my downfall#0006

